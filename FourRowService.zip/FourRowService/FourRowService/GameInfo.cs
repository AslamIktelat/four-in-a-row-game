﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace FourRowService
{
    [DataContract]
    public class GameInfo
    {
        [DataMember]
        public string FParticipant { get; set; }
        [DataMember]
        public string SParticipant { get; set; }
        [DataMember]
        public int FParticipantP { get; set; }
        [DataMember]
        public int SParticipantP { get; set; }
        [DataMember]
        public DateTime Time { get; set; }
        [DataMember]
        public bool Live { get; set; }
        [DataMember]
        public string Winner { get; set; }
        
    }
}
