﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FourRowService
{
    public class LiveGameInfo
    {
       public int MovesCount { get; set; }
        public Game game { get; set; }
        
    }
}
