﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace FourRowService
{
    [DataContract]
    public class CommonGamesInfo
    {
        [DataMember]
        public List<GameInfo> CommonGames { get; set; }
        [DataMember]
        public string Champion { get; set; }
        [DataMember]
        public int Precentage { get; set; }
    }
}
