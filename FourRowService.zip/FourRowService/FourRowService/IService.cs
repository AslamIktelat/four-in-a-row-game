﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace FourRowService
{
    
    [ServiceContract(CallbackContract = typeof(IServiceCallback))]
    public interface IService
    {
        [FaultContract(typeof(WrongPasswordFault))]
        [OperationContract]
        void ClientConnected(string userName, string hashedPasswd);
        [OperationContract]
        void ClientDisconnect(string userName);
       
        [OperationContract]
        Dictionary<string,Dictionary<string,int>> GetUsers();
        [OperationContract]
        Dictionary<int, GameInfo> GetGames();
        [OperationContract]
        CommonGamesInfo GetCommonGames(string p1,string p2);

        [OperationContract]
       string[] GetWaitingList();
        [OperationContract]
        GameInfo[] GetGamesByPlayer(string Id);
        [OperationContract]
        int[] GetPlayerInfo(string Id);
        [OperationContract]
        void AddPlayerToLobby(string Id);

        [FaultContract(typeof(InvitationFault))]
        [OperationContract]
        void SendInvitation(string FromId,string ToId);
        [FaultContract(typeof(InvitationFault))]
        [OperationContract]
        void InvitationAnswer(string FromId,bool YN);


        [FaultContract(typeof(LiveGameFault))]
        [OperationContract]
        void AddMyMoveToBoard(string username,string GameId,string col,bool IHaveFour);
        [FaultContract(typeof(LiveGameFault))]
        [OperationContract]
        void MyPoints(string username, string GameId,int p);
        [FaultContract(typeof(LiveGameFault))]
        [OperationContract]
        void IQuit(string userName, string GameId);
        [OperationContract]
        bool Ping();
        

        public interface IServiceCallback
        {
            
            [OperationContract(IsOneWay = true)]
            void ReceivedNewInvitation(string from);

            [OperationContract(IsOneWay = true)]
            void YourInvitationReturn(bool YN);


            [OperationContract(IsOneWay = true)]
            void YouLost();            
            [OperationContract(IsOneWay = true)]
            void Draw();
            [OperationContract(IsOneWay = true)]
            void Turn(bool flag);

            [OperationContract(IsOneWay = true)]
            void AddMoveToYourBoard(string col);
            [OperationContract(IsOneWay = true)]
            void PlayerQuit();
            
        }
    }

    

}
