﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Windows;
using System.Windows.Automation.Peers;
using static FourRowService.IService;

namespace FourRowService
{
    [ServiceBehavior(InstanceContextMode =InstanceContextMode.Single,ConcurrencyMode =ConcurrencyMode.Multiple)]
    public class Service : IService
    {
        Dictionary<string,IServiceCallback> connectedUsers = new Dictionary<string, IServiceCallback>();//the users in the lobby
        List<string> AvailableUser = new List<string>();//the user in the lobby and not playing
        Dictionary<string, string> Invitations = new Dictionary<string, string>();//Dictionary of the invtaions ,first string is who sent the invtaion , sec string is TO who the invtaion
        Dictionary<string, LiveGameInfo> LiveGames = new Dictionary<string, LiveGameInfo>();//Dictionary of the live games
        public bool Ping()
        {
            return true;
        }
        
        /*The client call this function when a new ball added to its game board*/
        public void AddMyMoveToBoard(string username, string GameId, string col, bool IHaveFour)
        {
               if(!LiveGames.ContainsKey(GameId))
               {
                AvailableUser.Add(username);
                LiveGameFault fault = new LiveGameFault
                {
                    Details = "This weird, the game you trying to access is not available"
                };
                throw new FaultException<LiveGameFault>(fault, new FaultReason("game not available"));
                }
               LiveGames[GameId].MovesCount= LiveGames[GameId].MovesCount +1;//we count in each game how many moves the two players did
              string otherplayer;//otherplayer is the second participant in the game
            if (username == GameId)
                   otherplayer = LiveGames[GameId].game.SParticipant;
               else
                   otherplayer = GameId;
              
               connectedUsers[otherplayer].AddMoveToYourBoard(col);//AddMoveToYourBoard is a callback function to add a ball at the game board
            if ((IHaveFour) || (LiveGames[GameId].MovesCount == 42)) //if we reach the end of the game
               {
                  
                  int gameId = LiveGames[GameId].game.Id;

                  if (IHaveFour)//the player "username" win and the "otherplayer" lost
                {
                    //we search for the game in DataBase 
                    //and assign the EndTime,Winner fields
                    using (var ctx = new fourinrowDB_AslamIktelatContext())
                       {
                           var LGame = (from g in ctx.Games
                                        where g.Id == gameId
                                        select g).FirstOrDefault();
                           LGame.EndTime = DateTime.Now;
                           LGame.Winner = username;
                           ctx.SaveChanges();
                       }
                       connectedUsers[otherplayer].YouLost();//YouLost is a callback function to notify the otherplayer that he/she lost the game
                }

                   else//Draw
                   {
                    //we search for the game in DataBase 
                    //and assign the EndTime,Winner fields
                    using (var ctx = new fourinrowDB_AslamIktelatContext())
                       {
                           var LGame = (from g in ctx.Games
                                        where g.Id == gameId
                                        select g).FirstOrDefault();
                          if(LGame!=null)
                          {
                              LGame.EndTime = DateTime.Now;
                              LGame.Winner = "Draw";
                              ctx.SaveChanges();
                          }

                       }
                       connectedUsers[otherplayer].Draw();//Draw is a callback function to notify the otherplayer that the game is over


                }

               }
              else
               { connectedUsers[otherplayer].Turn(true); }//Turn is a callback function to notify the otherplayer that its his/her turn

        }

        /*The client call this function when entering the game lobby*/
        public void AddPlayerToLobby(string Id)
        {
                IServiceCallback callback = OperationContext.Current.GetCallbackChannel<IServiceCallback>();
            //we check if the user found in connectedUsers,AvailableUser
            //in case the user disconnect and didnt call the function ClientConnected
            if (connectedUsers.ContainsKey(Id))
            {
                connectedUsers[Id] = callback;
                Invitations.Remove(Id);
                LiveGames.Remove(Id);
            }
               
            else
                connectedUsers.Add(Id, callback); //add the user to Dictionary connectedUsers
               if(!AvailableUser.Contains(Id))
                AvailableUser.Add(Id);//add the user to Dictionary AvailableUser
            
        }


        /*The client call this function when sign in/register to the game */
        public void ClientConnected(string userName, string hashedPasswd)
        {
            using (var ctx = new fourinrowDB_AslamIktelatContext())
            {
                var user = (from u in ctx.Users
                            where u.UserId == userName
                            select u).FirstOrDefault();//return null if not found
                if (user == null)//not found then add the user to the DataBase
                {
                    ctx.Users.Add(new User
                    {
                        UserId = userName,
                        HashedPassword = hashedPasswd,
                        Points=0,
                        WonCounter=0,
                        GamesCounter=0
                    });
                    ctx.SaveChanges();
                }
                else if (user.HashedPassword != hashedPasswd)//if found check the password
                {
                    WrongPasswordFault fault = new WrongPasswordFault
                    {
                        Details = "Wrong Password!"
                    };
                    throw new FaultException<WrongPasswordFault>(fault, new FaultReason("Wrong Password!"));
                    
                }
              
                    
            }
        }

        /*The client call this function when exiting the game lobby */
        public void ClientDisconnect(string userName)
        {
            //Remove the player from connectedUsers,AvailableUser
            connectedUsers.Remove(userName);
            AvailableUser.Remove(userName);
            Invitations.Remove(userName);//if the player sent an invitation then disconnect
            if (Invitations.ContainsValue(userName))//if the player disconnect before received the invitation
            {
                foreach (var item in Invitations)
                {
                    if (item.Value == userName)
                        Invitations.Remove(item.Key);
                }
            }

        }

        /*The client call this function after choosing two players to see the common games of the two players*/
        public CommonGamesInfo GetCommonGames(string p1, string p2)
        {
            CommonGamesInfo CGI = new CommonGamesInfo();
            using (var ctx = new fourinrowDB_AslamIktelatContext())
            {
                //we search for the common games of the two players
                var games = from g in ctx.Games
                            where (g.FParticipant == p1 || g.SParticipant == p1) && (g.FParticipant == p2 || g.SParticipant == p2)
                            &&(g.StartTime != g.EndTime)//not live game
                            select g;
                int w1=0, w2=0;
                List<GameInfo> res = new List<GameInfo>();
                foreach (var g in games)
                {
                    GameInfo info = new GameInfo
                    {
                        FParticipant = g.FParticipant,
                        SParticipant = g.SParticipant,
                        FParticipantP = g.FParticipantP,
                        SParticipantP = g.SParticipantP,
                        Time = g.StartTime,
                        Winner = g.Winner,
                        Live = false
                        
                    };
                    //we count for each player how many games won of the common games 
                    if (g.Winner.Equals(p1)) w1++;
                    else w2++;
                    res.Add(info);
                    
                }
                CGI.CommonGames = res;
                if (w1 > w2) { CGI.Champion = p1; CGI.Precentage = w1; }
                else  if(w1 == w2) { CGI.Champion = "Equal"; CGI.Precentage = w1; }  else { CGI.Champion = p2; CGI.Precentage = w2; }

                
            }
                return CGI;
        }

        /*The client call this function to get all the games in the DataBase*/
        public Dictionary<int,GameInfo> GetGames()  
        {
            Dictionary<int, GameInfo> res = new Dictionary<int, GameInfo>();
            /*delete games which are live games and opend more than 7 houers*/
            /* we do this if in case of the service disconnected and the players didnt finish their game */
            using (var ctx = new fourinrowDB_AslamIktelatContext())
            {
                var t = DateTime.Now;
                var gamesToDelete = (from g in ctx.Games where (g.StartTime == g.EndTime) select g).ToList<Game>();//get the live games  
                foreach (var member in gamesToDelete)
                {
                     if(DateTime.Now.Subtract(member.StartTime).TotalHours >= 7)
                         ctx.Games.Remove(member);
                }
                   
               
                    ctx.SaveChanges();
            }
            using (var ctx = new fourinrowDB_AslamIktelatContext())
            {
                
                var games = from g in ctx.Games select g;
               
                foreach (var g in games)
                {
                  //  MessageBox.Show(""+DateTime.Now.Subtract(g.StartTime).TotalHours);

                    GameInfo info = new GameInfo();
                    info.FParticipant = g.FParticipant;
                    info.SParticipant = g.SParticipant;
                    info.FParticipantP = g.FParticipantP;
                    info.SParticipantP = g.SParticipantP;
                    info.Time = g.StartTime;


                    if (g.EndTime == g.StartTime)//live game
                    {
                        info.Winner = "";
                        info.Live = true;
                    }
                       
                    else
                    {
                       info.Live = false;
                       info.Winner = g.Winner;
                    }
                   
                    res.Add(g.Id,info);
                }
            }
            return res;
        }

        /*The client call this function to get all the ended games of a player*/
        public GameInfo[] GetGamesByPlayer(string Id)
        {
            GameInfo[] res;
            using (var ctx = new fourinrowDB_AslamIktelatContext())
            {
                var games = from g in ctx.Games
                            where ( g.FParticipant == Id || g.SParticipant == Id )&& (g.StartTime != g.EndTime)//not live games
                            select g;
                int t = games.Count();
                res = new GameInfo[t];
                t = 0;
                foreach (var g in games)
                {
                    
                    GameInfo info = new GameInfo
                    {
                        FParticipant = g.FParticipant,
                        SParticipant = g.SParticipant,
                        FParticipantP = g.FParticipantP,
                        SParticipantP = g.SParticipantP,
                        Time = g.StartTime,
                        Live=false,
                        Winner=g.Winner
                    };


                    res[t] = info;
                    t++;
                }
            }
            return res;
        }

        /*The client call this function to get a player info*/
        public int[] GetPlayerInfo(string Id)
        {
            //we return an array in the cell0 a won counter
            //cell1 a lost counter
            //cell2 number of points the player gained
            //cell3 number of the games the player played
            int[] res =new int[4];
            using (var ctx = new fourinrowDB_AslamIktelatContext())
            {
                var user = (from u in ctx.Users
                            where u.UserId == Id
                            select u).FirstOrDefault();
                res[0]=user.WonCounter;
                res[1]=user.GamesCounter- user.WonCounter;
                res[2] = user.Points;
                res[3] = user.GamesCounter;


            }

                return res;
        }

        /*The client call this function to get all players info*/
        public Dictionary<string, Dictionary<string, int>> GetUsers()
        {
            Dictionary<string, Dictionary<string, int>> res = new Dictionary<string, Dictionary<string, int>>();
            using (var ctx = new fourinrowDB_AslamIktelatContext())
            {
                var users = from u in ctx.Users select u;
                foreach (var u in users)
                {
                    Dictionary<string, int> info = new Dictionary<string, int>();
                    info.Add("Points",u.Points);
                    info.Add("WonCounter", u.WonCounter);
                    info.Add("GamesCounter", u.GamesCounter); 
                    info.Add("Losses", u.GamesCounter - u.WonCounter);
                    res.Add(u.UserId, info);
                }
            }
            return res;
        }

        /*The client call this function to get all players whos in the lobby and availabl to play*/
        public string[] GetWaitingList()
        {
            return AvailableUser.ToArray<string>();
        }

        /*The client call this function to response to a invitation */
        public void InvitationAnswer(string FromId, bool YN)
        {
                if (YN)//accept
                {
                 if(!connectedUsers.ContainsKey(FromId))
                  {
                    Invitations.Remove(FromId);
                    InvitationFault fault = new InvitationFault
                    {
                        Details = "The player who sent you the invitation is no longer connected"
                    };
                    throw new FaultException<InvitationFault>(fault, new FaultReason("The player no longer connected"));
                  }
                 if(!Invitations.ContainsKey(FromId))
                {
                    InvitationFault fault = new InvitationFault
                    {
                        Details = "Invitation not found"
                    };
                    throw new FaultException<InvitationFault>(fault, new FaultReason("Invitation not found"));
                }
                    //add new game to the DataBase
                    using (var ctx = new fourinrowDB_AslamIktelatContext())
                    {
                    string otherP = Invitations[FromId];
                    //search if one of the two players has unfinished game in the database to delete
                    var gamesToDelete = (from gg in ctx.Games where (gg.StartTime == gg.EndTime)&&
                                         ((gg.SParticipant == FromId) || (gg.SParticipant == otherP) || (gg.FParticipant== FromId) ||(gg.FParticipant== otherP)) 
                                         select gg).ToList<Game>();
                    foreach (var member in gamesToDelete)
                    {
                        
                            ctx.Games.Remove(member);
                    }
                    var t = DateTime.Now;
                    Game g = new Game {
                        FParticipant = FromId,
                        SParticipant = Invitations[FromId],
                        FParticipantP = 0,
                        SParticipantP = 0,
                        StartTime = t,
                        EndTime=t
                    };
                   
                    LiveGameInfo lgi = new LiveGameInfo {game=ctx.Games.Add(g)};
                    ctx.SaveChanges();
                    lgi.MovesCount = 0;
                    LiveGames.Add(FromId, lgi);//Add the live game to the dictionary

                }
                //remove the two players from the available users dictionary
                AvailableUser.Remove(FromId);
                AvailableUser.Remove(Invitations[FromId]);
                }

            Invitations.Remove(FromId);//delete the Invitation
            //return answer to the other player
            if(connectedUsers.ContainsKey(FromId))
            connectedUsers[FromId].YourInvitationReturn(YN); //YourInvitationReturn is a callback function to notify the a player with an answer of the invation he/she sended
        }

        /*The client call this function when quiting the game before its ended*/
        public void IQuit(string userName, string GameId)
        {
            if (!LiveGames.ContainsKey(GameId))
            {
                AvailableUser.Add(userName);
                LiveGameFault fault = new LiveGameFault
                {
                    Details = "This weird, the game you trying to access is not available"
                };
                throw new FaultException<LiveGameFault>(fault, new FaultReason("game not available"));
            }

            //we search for the game in DataBase
            //the player who quited get 0 points 
            //the other player get 1000 points
            using (var ctx = new fourinrowDB_AslamIktelatContext())
            {
                string otherplayer;
            int gameId = LiveGames[GameId].game.Id;
            LiveGames.Remove(GameId);
            //update the game
                var LGame = (from g in ctx.Games
                             where g.Id == gameId 
                             select g).FirstOrDefault();
                
                    
                    LGame.EndTime = DateTime.Now;
                    if (LGame.FParticipant == userName)
                    {
                        LGame.FParticipantP = 0;
                        LGame.SParticipantP = 1000;
                        LGame.Winner = LGame.SParticipant;
                        otherplayer = LGame.SParticipant;
                    }
                    else
                    {
                        LGame.FParticipantP = 1000;
                        LGame.SParticipantP = 0;
                        LGame.Winner = LGame.FParticipant;
                        otherplayer = LGame.FParticipant;

                    }
                //update the points ,GamesCounter and the WonCounter of the players
                var pQ = (from p in ctx.Users where p.UserId==userName select p).FirstOrDefault();
                pQ.GamesCounter++;
                var PW= (from p in ctx.Users where p.UserId == otherplayer select p).FirstOrDefault();
                PW.GamesCounter++;
                PW.WonCounter++;
                PW.Points = PW.Points + 1000;
                //add the two players to the available users dictionary
                AvailableUser.Add(LGame.FParticipant);
                AvailableUser.Add(LGame.SParticipant);
                ctx.SaveChanges();
                connectedUsers[otherplayer].PlayerQuit();//PlayerQuit is a callback function to notify the otherplayer that the game is over 
                

            }
            
        }
        /*The client call this function when the game is over with draw or one of them won*/
        public void MyPoints(string username, string GameId, int p)
        {
            if (!LiveGames.ContainsKey(GameId))
            {
                AvailableUser.Add(username);
                LiveGameFault fault = new LiveGameFault
                {
                    Details = "This is weird, the game you trying to access is not available"
                };
                throw new FaultException<LiveGameFault>(fault, new FaultReason("game not available"));
            }
            //add the player back to the available users
            AvailableUser.Add(username);
            //update the player and the game in the datbase
            int gameId = LiveGames[GameId].game.Id;
            if (LiveGames[GameId].game.FParticipant==username)
             {
               
                LiveGames[GameId].game.FParticipantP = p;
                using (var ctx = new fourinrowDB_AslamIktelatContext())
                       {
                        var LGame = (from g in ctx.Games
                                     where g.Id == gameId
                                     select g).FirstOrDefault();
                    LGame.FParticipantP = p;
                        var player= (from p1 in ctx.Users
                                     where p1.UserId == username
                                     select p1).FirstOrDefault();
                        player.GamesCounter++;
                        player.Points = player.Points + p;
                        if (LGame.Winner == username)
                            player.WonCounter++;
                    ctx.SaveChanges();
                       }
            }
            else
            {
                LiveGames[GameId].game.SParticipantP = p;
                using (var ctx = new fourinrowDB_AslamIktelatContext())
                {
                    var LGame = (from g in ctx.Games
                                 where g.Id == gameId
                                 select g).FirstOrDefault();
                    LGame.SParticipantP = p;
                    var player = (from p1 in ctx.Users
                                  where p1.UserId == username
                                  select p1).FirstOrDefault();
                    player.GamesCounter++;
                    if (LGame.Winner == username)
                        player.WonCounter++;
                    ctx.SaveChanges();
               }
            }
           if (LiveGames[GameId].game.FParticipantP > 0 && LiveGames[GameId].game.SParticipantP > 0)//if the two players update their points no need to keep the game
                LiveGames.Remove(GameId);                                                           //in the LiveGames dictionary 
        }

        /*The client call this function when to send invitation*/
        public void SendInvitation(string FromId, string ToId)
        {
            if(Invitations.ContainsKey(ToId))  
            {
                InvitationFault fault = new InvitationFault
                {
                    Details = "The player sent a invitation that hasn't got an answer to it yet"
                };
                throw new FaultException<InvitationFault>(fault, new FaultReason("player cant receive new invitation"));
            }
            if(Invitations.ContainsValue(ToId))
            {
                InvitationFault fault = new InvitationFault
                {
                    Details = "The player received invitation that hasn't answered to it yet, each player can get only one invitation at a time"
                };
                throw new FaultException<InvitationFault>(fault, new FaultReason("player cant receive new invitation"));
            }
            if(Invitations.ContainsValue(FromId))
            {
                InvitationFault fault = new InvitationFault
                {
                    Details = "You have sent a invitation before, please wait for answer then you can send new invitations"
                };
                throw new FaultException<InvitationFault>(fault, new FaultReason("player cant send new invitation"));
            }
            if (!connectedUsers.ContainsKey(ToId))
            {
                InvitationFault fault = new InvitationFault
                {
                    Details = ToId+ " no longer online"
                };
                throw new FaultException<InvitationFault>(fault, new FaultReason("player cant send new invitation"));
            }
            if (!AvailableUser.Contains(ToId))
            {
                InvitationFault fault = new InvitationFault
                {
                    Details = ToId + " playing,can't respond"
                };
                throw new FaultException<InvitationFault>(fault, new FaultReason("player cant send new invitation"));
            }

            Invitations.Add(FromId, ToId);//Add the invitation to the Invitations dictionary 
            connectedUsers[ToId].ReceivedNewInvitation(FromId);//ReceivedNewInvitation is a callback function to notify the otherplayer that he/she received a new invitation 
        }

       
    }
}
