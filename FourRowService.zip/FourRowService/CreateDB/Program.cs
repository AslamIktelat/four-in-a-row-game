﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreateDB
{
    class Program
    {
        static void Main(string[] args)
        {
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog= fourinrowDB_AslamIktelat;AttachDbFilename=C:\fourinrow\databases\fourinrowDB_AslamIktelat.mdf;Integrated Security=True";
            using (var ctx = new DataContext(connectionString))
            {
                ctx.Database.Initialize(force: true);
            }
        }
    }
}
